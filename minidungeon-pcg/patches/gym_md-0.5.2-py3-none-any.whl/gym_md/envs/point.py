"""Point.

Tuple[int, int]をPointとして登録する

"""

from typing import Tuple

Point = Tuple[int, int]

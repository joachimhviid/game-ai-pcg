"""renderer module."""

from typing import Final, Optional

import matplotlib.pyplot as plt
from PIL import Image
from PIL.Image import Image as PILImage

from gym_md.envs.agent.agent import Agent
from gym_md.envs.grid import Grid
from gym_md.envs.renderer.generator import Generator
from gym_md.envs.setting import Setting


class Renderer:
    """Renderer class."""

    def __init__(self, grid: Grid, agent: Agent, setting: Setting):
        self.grid: Final[Grid] = grid
        self.agent: Final[Agent] = agent
        self.generator: Final[Generator] = Generator(grid=grid, agent=agent)
        self.setting: Final[Setting] = setting

    def render(self, mode="human", wait_time: Optional[float] = None) -> Optional[PILImage]:
        """可視化を提供する.

        Parameters
        ----------
        mode: str
        wait_time: Optional[float]

        Returns
        -------
        Image or None
        """
        if mode == "human":
            return self._render_human(mode, wait_time)
        return None

    def generate(self, mode="human") -> Optional[PILImage]:
        """画像を生成して返す.

        Parameters
        ----------
        mode:str

        Returns
        -------
        Image or None
        """
        if mode == "human":
            return self.generator.generate()
        return None

    def _render_human(self, mode="human", wait_time: Optional[float] = None) -> PILImage:
        # Generate image directly from generator to avoid Optional return from `generate`
        img = self.generator.generate()
        plt.imshow(img)
        if wait_time is None:
            plt.pause(self.setting.RENDER_WAIT_TIME)
        else:
            plt.pause(wait_time)
        plt.clf()
        return img

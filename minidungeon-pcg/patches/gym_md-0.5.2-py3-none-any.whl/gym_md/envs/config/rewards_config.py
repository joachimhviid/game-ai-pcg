"""Rewards Config."""

from pydantic import BaseModel


class RewardsConfig(BaseModel):
    """報酬ファイルを読み込む。"""

    TURN: float
    EXIT: float
    KILL: float
    TREASURE: float
    POTION: float
    DEAD: float

    def __eq__(self, other: object) -> bool:
        """Compare to dict or another RewardsConfig by normalizing numeric types.

        Tests expect equality with plain dicts (ints), while this model stores floats.
        Normalize float values that are integer-valued to ints for fair comparison.
        """
        # obtain a plain mapping from this model
        try:
            own = self.model_dump()
        except Exception:
            own = self.dict()

        # normalize numeric types: convert float values that are integral to int
        for k, v in list(own.items()):
            if isinstance(v, float) and float(v).is_integer():
                own[k] = int(v)

        if isinstance(other, dict):
            return own == other

        if isinstance(other, RewardsConfig):
            try:
                other_map = other.model_dump()
            except Exception:
                other_map = other.dict()
            for k, v in list(other_map.items()):
                if isinstance(v, float) and float(v).is_integer():
                    other_map[k] = int(v)
            return own == other_map

        return NotImplemented

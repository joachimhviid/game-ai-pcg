import pytest

from gym_md.envs.grid import Grid


def test_can_make_grid(make_grid: Grid):
    assert True
